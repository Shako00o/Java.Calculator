package scientificcalculator;

import javax.swing.SwingUtilities;
import scientificcalculator.ui.CalculatorUI;

public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new CalculatorUI().createAndShowGUI());
    }
}