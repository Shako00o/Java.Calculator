package scientificcalculator.operations;

public abstract class MathOperation {
    public abstract double calculate(double a, double b);
}