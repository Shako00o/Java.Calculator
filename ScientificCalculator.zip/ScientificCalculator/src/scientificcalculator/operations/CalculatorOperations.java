package scientificcalculator.operations;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CalculatorOperations implements ActionListener {
    private JTextField display;
    private String current = "";
    private double result = 0;
    private String operator = "";

    public CalculatorOperations(JTextField display) {
        this.display = display;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String cmd = e.getActionCommand();
        if (cmd.matches("[0-9]") || cmd.equals(".")) {
            current += cmd;
            display.setText(current);
        } else if (cmd.equals("C")) {
            current = "";
            operator = "";
            result = 0;
            display.setText("");
        } else if (cmd.equals("=")) {
            calculate(Double.parseDouble(current));
            display.setText(String.valueOf(result));
            current = "";
        } else if (cmd.equals("sqrt")) {
            double value = Math.sqrt(Double.parseDouble(current));
            display.setText(String.valueOf(value));
            current = "";
        } else if (cmd.equals("sin")) {
            double value = Math.sin(Math.toRadians(Double.parseDouble(current)));
            display.setText(String.valueOf(value));
            current = "";
        } else if (cmd.equals("cos")) {
            double value = Math.cos(Math.toRadians(Double.parseDouble(current)));
            display.setText(String.valueOf(value));
            current = "";
        } else {
            result = Double.parseDouble(current);
            operator = cmd;
            current = "";
        }
    }

    private void calculate(double value) {
        switch (operator) {
            case "+": result += value; break;
            case "-": result -= value; break;
            case "*": result *= value; break;
            case "/": result /= value; break;
        }
    }
}
