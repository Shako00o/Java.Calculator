package scientificcalculator.operations;

public class ScientificOperation {
    public double sqrt(double x) {
        return Math.sqrt(x);
    }

    public double power(double base, double exp) {
        return Math.pow(base, exp);
    }

    public double log(double x) {
        return Math.log10(x);
    }

    public double ln(double x) {
        return Math.log(x);
    }

    public double sin(double x) {
        return Math.sin(Math.toRadians(x));
    }

    public double cos(double x) {
        return Math.cos(Math.toRadians(x));
    }

    public double tan(double x) {
        return Math.tan(Math.toRadians(x));
    }

    public double exp(double x) {
        return Math.exp(x);
    }

    public double tenPowerX(double x) {
        return Math.pow(10, x);
    }
}
