package scientificcalculator.operations;

public class MemoryOperation {
    private double memory = 0.0;

    public void memoryStore(double value) {
        memory = value;
    }

    public double memoryRecall() {
        return memory;
    }

    public void memoryClear() {
        memory = 0.0;
    }

    public void memoryAdd(double value) {
        memory += value;
    }

    public void memorySubtract(double value) {
        memory -= value;
    }
}
