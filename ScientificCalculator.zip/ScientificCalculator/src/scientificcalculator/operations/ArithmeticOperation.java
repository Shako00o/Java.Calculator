package scientificcalculator.operations;

public class ArithmeticOperation extends MathOperation {
    private String operator;

    public ArithmeticOperation(String operator) {
        this.operator = operator;
    }

    @Override
    public double calculate(double a, double b) {
        switch (operator) {
            case "+": return a + b;
            case "-": return a - b;
            case "*": return a * b;
            case "/": return b != 0 ? a / b : Double.NaN;
            case "%": return a % b;
            default: throw new IllegalArgumentException("Invalid operator");
        }
    }
}
