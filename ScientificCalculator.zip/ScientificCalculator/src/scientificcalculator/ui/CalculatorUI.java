package scientificcalculator.ui;

import scientificcalculator.operations.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class CalculatorUI {
    private JTextField display = new JTextField();
    private String currentInput = "";
    private double storedValue = 0;
    private String currentOperator = "";
    private MemoryOperation memory = new MemoryOperation();
    private ScientificOperation sciOps = new ScientificOperation();

    public void createAndShowGUI() {
        JFrame frame = new JFrame("Scientific Calculator");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(560, 720);
        frame.setLayout(new BorderLayout());
        frame.setLocationRelativeTo(null);

        UIManager.put("Button.focus", new Color(0, 0, 0, 0));
        Font modernFont = new Font("Segoe UI", Font.BOLD, 20);

        display.setEditable(false);
        display.setFont(new Font("Segoe UI", Font.BOLD, 36));
        display.setHorizontalAlignment(JTextField.RIGHT);
        display.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        display.setBackground(new Color(245, 245, 245));
        display.setForeground(Color.BLACK);
        frame.getContentPane().setBackground(new Color(240, 240, 240));
        frame.add(display, BorderLayout.NORTH);

        JPanel buttonPanel = new JPanel(new GridLayout(7, 5, 8, 8));
        buttonPanel.setBackground(new Color(240, 240, 240));
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        String[][] buttonRows = {
            {"sin", "cos", "tan", "=", "C"},
            {"7", "8", "9", "+", "M+"},
            {"4", "5", "6", "-", "M-"},
            {"1", "2", "3", "*", "MS"},
            {"0", ".", "+/-", "/", "MR"},
            {"x^y", "log", "ln", "%", "MC"},
            {"sqrt"}
        };

        for (String[] row : buttonRows) {
            for (String text : row) {
                RoundedButton button = new RoundedButton(text);
                button.setFont(modernFont);
                button.setToolTipText(getTooltip(text));

                // Color by category
                if ("C".equals(text)) {
                    button.setBackground(new Color(255, 180, 180));
                } else if ("=".equals(text)) {
                    button.setBackground(new Color(170, 210, 255));
                } else if ("+".equals(text) || "-".equals(text) || "*".equals(text) || "/".equals(text) || "%".equals(text)) {
                    button.setBackground(new Color(255, 255, 180));
                } else if ("x^y".equals(text) || "log".equals(text) || "ln".equals(text) || "sqrt".equals(text)) {
                    button.setBackground(new Color(200, 255, 255));
                } else if ("sin".equals(text) || "cos".equals(text) || "tan".equals(text)) {
                    button.setBackground(new Color(230, 200, 255));
                } else if (text.startsWith("M")) {
                    button.setBackground(new Color(210, 230, 255));
                }

                button.addActionListener(e -> handleInput(e.getActionCommand()));
                buttonPanel.add(button);
            }
        }

        frame.add(buttonPanel, BorderLayout.CENTER);
        frame.setVisible(true);
    }

    private String getTooltip(String text) {
        return switch (text) {
            case "C" -> "Clear input";
            case "=" -> "Calculate result";
            case "+" -> "Addition";
            case "-" -> "Subtraction";
            case "*" -> "Multiplication";
            case "/" -> "Division";
            case "%" -> "Modulo";
            case "x^y" -> "Power";
            case "sqrt" -> "Square root";
            case "log" -> "Log base 10";
            case "ln" -> "Natural log";
            case "sin" -> "Sine";
            case "cos" -> "Cosine";
            case "tan" -> "Tangent";
            case "+/-" -> "Toggle sign";
            case "." -> "Decimal point";
            case "MS" -> "Memory Store";
            case "MR" -> "Memory Recall";
            case "MC" -> "Memory Clear";
            case "M+" -> "Memory Add";
            case "M-" -> "Memory Subtract";
            default -> "Number " + text;
        };
    }

    private void handleInput(String input) {
        try {
            switch (input) {
                case "C" -> {
                    currentInput = "";
                    storedValue = 0;
                    currentOperator = "";
                    display.setText("");
                }
                case "=" -> performCalculation();
                case "+", "-", "*", "/", "%" -> {
                    storedValue = Double.parseDouble(currentInput);
                    currentOperator = input;
                    currentInput = "";
                }
                case "sqrt" -> showResult(sciOps.sqrt(Double.parseDouble(currentInput)));
                case "x^y" -> {
                    currentOperator = "x^y";
                    storedValue = Double.parseDouble(currentInput);
                    currentInput = "";
                }
                case "log" -> showResult(sciOps.log(Double.parseDouble(currentInput)));
                case "ln" -> showResult(sciOps.ln(Double.parseDouble(currentInput)));
                case "sin" -> showResult(sciOps.sin(Double.parseDouble(currentInput)));
                case "cos" -> showResult(sciOps.cos(Double.parseDouble(currentInput)));
                case "tan" -> showResult(sciOps.tan(Double.parseDouble(currentInput)));
                case "+/-" -> {
                    if (!currentInput.isEmpty()) {
                        double val = Double.parseDouble(currentInput);
                        currentInput = String.valueOf(-val);
                        display.setText(currentInput);
                    }
                }
                case "MS" -> memory.memoryStore(Double.parseDouble(display.getText()));
                case "MR" -> {
                    double recall = memory.memoryRecall();
                    currentInput = String.valueOf(recall);
                    display.setText(currentInput);
                }
                case "MC" -> memory.memoryClear();
                case "M+" -> memory.memoryAdd(Double.parseDouble(display.getText()));
                case "M-" -> memory.memorySubtract(Double.parseDouble(display.getText()));
                default -> {
                    currentInput += input;
                    display.setText(currentInput);
                }
            }
        } catch (Exception ex) {
            display.setText("Error");
        }
    }

    private void performCalculation() {
        double inputVal = Double.parseDouble(currentInput);
        double result = switch (currentOperator) {
            case "+" -> storedValue + inputVal;
            case "-" -> storedValue - inputVal;
            case "*" -> storedValue * inputVal;
            case "/" -> inputVal != 0 ? storedValue / inputVal : Double.NaN;
            case "%" -> storedValue % inputVal;
            case "x^y" -> Math.pow(storedValue, inputVal);
            default -> inputVal;
        };
        showResult(result);
        currentOperator = "";
    }

    private void showResult(double value) {
        if (Math.abs(value) < 1e-10) value = 0;
        display.setText(String.valueOf(value));
        currentInput = String.valueOf(value);
    }

    // 🔶 Custom Rounded Button Class
    static class RoundedButton extends JButton {
        public RoundedButton(String text) {
            super(text);
            setFocusPainted(false);
            setContentAreaFilled(false);
            setBorderPainted(false);
            setOpaque(false);
            setCursor(new Cursor(Cursor.HAND_CURSOR));
            setFont(new Font("Segoe UI", Font.BOLD, 18));
            setMargin(new Insets(10, 10, 10, 10));
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(getModel().isArmed() ? getBackground().darker() : getBackground());
            g2.fillRoundRect(0, 0, getWidth(), getHeight(), 20, 20);
            g2.setColor(getForeground());
            FontMetrics fm = g2.getFontMetrics();
            int x = (getWidth() - fm.stringWidth(getText())) / 2;
            int y = (getHeight() + fm.getAscent()) / 2 - 4;
            g2.drawString(getText(), x, y);
            g2.dispose();
        }

        @Override
        protected void paintBorder(Graphics g) {}
    }
}
